﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

           
            float salary = Convert.ToInt32(salary1.Text);
            float tax = Convert.ToInt32(salary2.Text);
            float groceries = Convert.ToInt32(salary3.Text);
            float waterlights = Convert.ToInt32(salary4.Text);
            float telephone = Convert.ToInt32(tele.Text);
            float other = Convert.ToInt32(othere.Text);



            if (Rent.IsChecked == true)
            {
                a.IsEnabled = false;
                b.IsEnabled = false;
                c.IsEnabled = false;
                d.IsEnabled = false;


                float MonthlyRent = Convert.ToInt32(Rentm.Text);

                float final = salary - tax - groceries - waterlights -other-telephone- MonthlyRent;
                MessageBox.Show("Avaliable Balance:" + final);
            }

            if (Buy.IsChecked == true)
            {
                Rentm.IsEnabled = false;
                Rent.IsEnabled = false;

                float Amount1 = Convert.ToInt32(a.Text);
                float Deposit2 = Convert.ToInt32(b.Text);
                float Interest3 = Convert.ToInt32(c.Text);
                float Months4 = Convert.ToInt32(d.Text);

                float fresh = calculator(Amount1 - Deposit2, Interest3, Months4 / 12);

                float calculator(float p, float r, float t)
                {
                    float last;

                    r = r / (12 * 100); //  month interest
                    t = t * 12; // month period
                    last = (p * r * (float)Math.Pow(1 + r, t))
                    / (float)(Math.Pow(1 + r, t) - 1);

                    return (last);
                }

                float availableMoney = salary - (tax + groceries + waterlights +other+telephone+ fresh);
                MessageBox.Show("Avaliable balance" + availableMoney);
            }
            if (car.IsChecked == true)
            {
                float purcharse = Convert.ToInt32(k.Text);
                float Deposit = Convert.ToInt32(l.Text);
                float Interest = Convert.ToInt32(f.Text);
                float Insurance = Convert.ToInt32(g.Text);

                float calculator(float p, float r, float t)
                {
                    float last;

                    r = r / (12 * 100); //  month interest
                    t = t * 12; // month period
                    last = (p * r * (float)Math.Pow(1 + r, t))
                    / (float)(Math.Pow(1 + r, t) - 1);

                    return (last);
                }

                float vechilcek = calculator(purcharse - Deposit + Insurance, Interest, 5);
                MessageBox.Show("Avaliable balance" + vechilcek);

            }

            if (Savings.IsChecked == true)
            {
                float balance = Convert.ToInt32(x.Text);

                float Months = Convert.ToInt32(z.Text);
               
                float Save = balance / Months;

                MessageBox.Show("Money to be put away" + Save);
            }
        }

            private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
            {

            }
        }
    }
